    var i=0; //indice
	var j;
	var a=0;
	var bool=false; //Temp
	var Domande=["Frau1","Frau2","Frau3","Frau4"]; //Lista Domande
	var V_nd=[1,2,4]; //Domande da scegliere
	var V_Domande=[]; //Domande scelte Paralleli
	var V_Risposte=[]; //Risposte date //
		for(j=0;j<V_nd.length;j++) //Riempio vettore domande scelte
		{
			V_Domande[j]=Domande[V_nd[j]-1];
		}
		
	function Incremento()
	{
		$("#Domanda").text(V_Domande[++i]);
	}
	
	function Decremento()
	{
		$("#Domanda").text(V_Domande[--i]);
	}

	function Reset(arg1)
	{
		//if(a>0)
		{
			//a=0;
		}
		if(a>1)
		{
			$(arg1).prop("checked", true);
			a=0;
		}
	}
	
	function RimuoviSpunta(arg1)
	{
		
		a=a+1;
		console.log("p1");

		if(a>1)
		{
			 console.log("p2");
			a=0;
			$(arg1).prop("checked", false);
		}
		if(a==1)
		{
			 console.log("p3");
			$(arg1).prop("checked", true);
			a++;
		}
		
		//console.log("sono qui");
	/*	if($(arg1).checked==true)// && bool==false)
		{
			console.log("p1");
			$(arg1).prop("checked", false);
			//$(arg1).toggle();
		} */ 
	}
	$('#Risposte input:radio').click(function() 
{
    if ($(this).val() === 'Molto importante')
	{
      //V_Risposte[i]=$(this).val();
	  V_Risposte[i]=$("input[type=text][name=rd]").val();
    } 
	else if ($(this).val() === 'Abbastanza importante') 
	{
	  V_Risposte[i]=$("input[type=text][name=rd]").val();
    } 
	else if ($(this).val() === 'Poco importante') 
	{
	  V_Risposte[i]=$("input[type=text][name=rd]").val();
    } 
});	